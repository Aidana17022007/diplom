"""Package the original diploma plus this committed frontend and diagnostics.

Never overwrites archives, models, original research reports or draft documents.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def main():
    site = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    original, destination = args.archive.resolve(), args.destination.resolve()
    if destination.exists():
        raise FileExistsError(f'Preserve existing archive: {destination}')
    version = json.loads((site / 'package.json').read_text(encoding='utf-8'))['version']
    if version != '2.5.0':
        raise ValueError('This overlay was verified for release 2.5.0')
    if subprocess.check_output(['git', '-C', str(site), 'status', '--porcelain']).strip():
        raise RuntimeError('Commit completed source before packaging')
    tracked = subprocess.check_output(['git', '-C', str(site), 'ls-files', '-z']).decode().split('\0')
    release = '''## Обновление 2.5 — диагностика и перенос модели

- Новый раздел «Диагностика модели»: 19 метрик, разбор ошибок, сравнение с простыми ориентирами, калибровка с числом наблюдений и условными интервалами Wilson, распределение вероятностей и CSV/JSON.
- Дополнительный ретроспективный опыт: фиксированная UCI Random Forest проверена отдельно на Hungary (294), Switzerland (123) и VA (200). Учтены пропуски, нули и различия состава выборок. Это исследовательская оценка переноса, не клиническая валидация.
- Модели и пороги сохранены. Основные метрики сверены с исходными отчётами. UCI OOF, среднее внешней CV и результаты других центров обозначены отдельно.
- Интерфейс RU/KZ, 3D-артерия, сценарии и раздел готовности диплома сохранены. Новые агрегированные API работают и в локальном Python-приложении.
- Исходные модели и прежние исследовательские отчёты сохранены; добавлены reports/evaluation.json и reports/transfer.json. Воспроизведение описано в deployment/cardio-site/docs/EVALUATION.md.
- Прежние PDF и HTML в output сохранены как черновики. Текст диплома и описание новых опытов требуют авторской актуализации; обновление приложения не подтверждает готовность рукописи к сдаче.

'''
    root = 'CardioResearch/'
    with zipfile.ZipFile(original) as source, zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for entry in source.infolist():
            if entry.filename.startswith((root+'frontend/', root+'deployment/cardio-site/')):
                continue
            payload = source.read(entry)
            if entry.filename == root+'README.md':
                lines = payload.decode('utf-8-sig').splitlines(keepends=True)
                if not lines or lines[0].strip() != '# CardioResearch':
                    raise ValueError('Unexpected README header')
                payload = ('# CardioResearch\n\n'+release+''.join(lines[1:])).encode('utf-8')
            elif entry.filename == root+'cardio/api.py':
                text = payload.decode('utf-8-sig')
                marker = "dist=ROOT/'frontend'/'dist'"
                if text.count(marker) != 1:
                    raise ValueError('Unexpected API layout; do not silently skip route registration')
                text = text.replace(marker, 'from .evaluation import register_evaluation_routes\nregister_evaluation_routes(app, REPORTS)\n\n'+marker)
                text = text.replace("version='2.0.0'", "version='2.5.0'")
                compile(text, 'cardio/api.py', 'exec')
                payload = text.encode('utf-8')
            output.writestr(entry.filename, payload)
        output.write(site/'python/cardio/evaluation.py', root+'cardio/evaluation.py')
        for name in ['evaluation', 'transfer']:
            output.write(site/f'data/{name}.json', root+f'reports/{name}.json')
        for name in filter(None, tracked):
            output.write(site/name, root+'deployment/cardio-site/'+name)
            if name.startswith('client/'):
                output.write(site/name, root+'frontend/'+name[len('client/'):])
        for path in (site/'client/dist').rglob('*'):
            if path.is_file():
                output.write(path, root+'frontend/dist/'+path.relative_to(site/'client/dist').as_posix())
    with zipfile.ZipFile(original) as source, zipfile.ZipFile(destination) as result:
        assert result.testzip() is None
        assert len(result.namelist()) == len(set(result.namelist()))
        preserved = 0
        for name in source.namelist():
            if name.startswith((root+'models/', root+'reports/', root+'output/')):
                assert hashlib.sha256(source.read(name)).digest() == hashlib.sha256(result.read(name)).digest(), name
                preserved += 1
        for name in ['cardio/evaluation.py', 'reports/evaluation.json', 'reports/transfer.json', 'frontend/src/EvaluationLab.tsx', 'frontend/dist/index.html']:
            assert root+name in result.namelist(), name
        assert 'register_evaluation_routes(app, REPORTS)' in result.read(root+'cardio/api.py').decode()
    print(json.dumps({'archive':str(destination), 'version':version, 'bytes':destination.stat().st_size,
                      'entries':len(result.namelist()), 'preserved_original_models_reports_drafts':preserved}, ensure_ascii=False))


if __name__ == '__main__':
    main()
