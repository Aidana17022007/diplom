# CardioResearch hosted application

This directory is the deployable Cloudflare Worker edition of the real diploma application. Training remains in the Python project. The hosted API uses the exact fitted Logistic Regression and Random Forest parameters exported from those saved artifacts; it does not train models or substitute synthetic probabilities.

## Rebuild

Run `npm ci`, then `npm run build` and `npm test` in this directory. `npm run dev` serves the built Worker locally on port 8787. The browser frontend source is retained in `client/`; its production output is retained in `public/`. To change the frontend, build `client` and replace the corresponding files in `public` before building the Worker.

The original project contains `scripts/export_web_models.py` and `scripts/export_site_payload.py` to refresh model artifacts and aggregate research results. After refreshing, rerun the model parity tests before publication. The read-only experiment journal contains actual exported training snapshots; a new website deployment is not a new training run.

## Verification and scope

Version 2.2 adds an owner-only one-feature scenario API (`POST /api/scenarios`, at most nine distinct values and 32 KiB), fixed public examples (`GET /api/scenario-demo/{dataset}`), and an allowlisted aggregate reproducibility download (`GET /api/reproducibility/{dataset}`). Scenarios call the same fitted model and report probability differences, not causal effects or future clinical risk. The matching Python API is tested against the Worker outputs.

The frontend includes a scenario chart and table, up to four comparisons kept only while that page is mounted, an explicit owner CSV export, a searchable feature atlas, a metric glossary, defense rehearsal cards, an arithmetic BMI helper, quick section navigation, and model-table search/sorting. Rehearsal progress is a personal practice indicator, not evidence that scientific checks have passed. These additions do not retrain or reselect the deployed models.

- 1,063 BRFSS and 509 UCI cases were compared with the original Python artifacts, including missing values and forest split-boundary probes. Maximum observed probability difference was 2.22e-16.
- Shapley calculations use the same 48 orders and 30 background observations as the original application and explain raw probability before additional calibration.
- API tests cover actual prediction, validation, bounded CSV parsing, safe exports, PDF, unavailable routes and private file exclusion.
- Training environment metadata describes the original Python experiment. Hosted execution is JavaScript, not Python. Timing in research tables still describes the original experiment.

## Data boundaries

Only `public/` assets are exposed as files. Model parameters, SHAP backgrounds and report objects are bundled in server code. There is no model/background download endpoint. Aggregate report endpoints are explicitly enumerated; raw source archives, row identifiers, test predictions, student profile, full training tables and local SQLite files are excluded from this deployment.

The server temporarily receives submitted form values to calculate a result. The application does not persist those values, log request bodies or send them to an analytics service. Prediction, PDF and CSV responses use `Cache-Control: no-store`. CSV is limited to 1 MiB and 1,000 data rows; JSON is limited to 32 KiB.

The model bundle includes 30 predictor rows from each public source for Shapley calculations. Their original-source membership was checked; this is not a claim of formally proven anonymity. The owner explicitly authorized transferring this server-side bundle to the hosting provider.

## Public demo and owner access

The owner requested a publicly accessible demo without ChatGPT sign-in. Guests can read aggregate research and obtain two fixed, clearly marked synthetic example predictions. Arbitrary form predictions, PDF reports and CSV upload/processing require the owner session on the server; disabling interface controls is not the authorization boundary. The demo endpoint ignores additional input and uses only its predefined rows.

Configure `CARDIO_AUTH_USERNAME`, `CARDIO_AUTH_PASSWORD_HASH` and `CARDIO_SESSION_SECRET` as secret hosting environment variables. Never commit their values. Password hashes use `pbkdf2-sha256$100000$<base64url salt>$<base64url digest>` with PBKDF2-HMAC-SHA256, a random 16-byte salt and a 32-byte digest. The session secret is a base64url-encoded random 32-byte key. After changing secrets, deploy a saved version to apply the new environment revision.

Sessions last eight hours and are origin- and credential-bound HMAC tokens in a `__Host-` cookie with Secure, HttpOnly and SameSite=Strict. Every POST requires the exact site Origin. Login bodies are limited to 4 KiB; missing configuration fails closed. No password or session token is stored in browser localStorage. Logout clears the browser cookie and form state; individual copied tokens cannot be revoked in this stateless design. Rotating the session secret or password hash revokes all previous sessions. The bounded login-attempt limit is best effort per Worker isolate, not a globally coordinated rate limit.

`npm test` runs authentication and Worker route tests using synthetic credentials. Local `npm run dev` has no owner credentials by default and exposes the demo only; the original Python application remains a separate full local workflow bound to loopback by `START.cmd`. Do not expose that local development server to the internet as a replacement for this authenticated Worker.

## Source attribution

- CDC, Behavioral Risk Factor Surveillance System, 2023: https://www.cdc.gov/brfss/annual_data/annual_2023.html. Local source version fingerprints are retained in the original project's reports; the current website may offer a revised dataset.
- Janosi, A., Steinbrunn, W., Pfisterer, M., and Detrano, R. Heart Disease (1989), UCI Machine Learning Repository. https://doi.org/10.24432/C52P4X. CC BY 4.0; the source permits sharing and adaptation with attribution. The project uses the documented Cleveland predictor subset, transforms its features, and trains classifiers.
- DejaVu Sans is embedded in PDF reports; see `assets/FONT_LICENSE.txt`.

This is a research application, not a clinical diagnostic service or a validated forecast of a future cardiovascular event. No independent clinical or Kazakhstan population validation has been performed.
