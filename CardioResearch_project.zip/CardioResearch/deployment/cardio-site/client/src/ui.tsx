import {useEffect,useRef,useState,ReactNode} from 'react';
import {Info,LoaderCircle,AlertCircle,ArrowUpRight} from 'lucide-react';

export type Lang='ru'|'kk';
export type T=(ru:string,kk:string)=>string;
export type Field={name:string;label:string;kind:string;group:string;source?:string;options?:{value:number;label:string}[];min?:number;max?:number;step?:number};
export type Values=Record<string,number|null>;
export const colors=['#138f81','#537eac','#d29b47','#9b75ad','#65a799','#bf7780','#849d4b','#8d9aa8'];
export const metricNames:Record<string,string>={roc_auc:'ROC-AUC',average_precision:'Average Precision',accuracy:'Accuracy',precision:'Precision',recall:'Recall',specificity:'Specificity',f1:'F1',brier:'Brier score'};
export const fmt=(n:number,d=3)=>Number.isFinite(n)?n.toFixed(d):'—';
export const count=(n:number)=>Number(n||0).toLocaleString('ru-RU');
export function errorText(value:any):string{
  if(typeof value==='string')return value;
  if(Array.isArray(value))return value.map(errorText).join('; ');
  if(value?.message)return value.message+(value.errors?.length?' · '+value.errors.map((e:any)=>`${e.label||e.field||''}: ${e.message||errorText(e)}`).join('; '):'');
  if(value?.errors)return errorText(value.errors);
  if(value?.msg)return `${value.loc?.slice(-1).join('')||''}: ${value.msg}`;
  return 'Не удалось выполнить запрос / Сұрау орындалмады';
}
export async function api(path:string,init?:RequestInit){const r=await fetch('/api'+path,init);if(!r.ok){let e;try{e=await r.json()}catch{e={detail:r.statusText}}throw Error(errorText(e.detail||e))}return r.json()}
export function post(values:Values,dataset:string,explain=true,lang:Lang='ru'){return {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({dataset,values,explain,lang})}}
export async function downloadResponse(response:Response,name:string){if(!response.ok){let e;try{e=await response.json()}catch{e={detail:response.statusText}}throw Error(errorText(e.detail||e))}const url=URL.createObjectURL(await response.blob());const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
export function Card({title,subtitle,children,className='',action}:{title?:string;subtitle?:string;children:ReactNode;className?:string;action?:ReactNode}){return <section className={'card '+className}>{title&&<div className="card-heading"><div><h2>{title}</h2>{subtitle&&<p>{subtitle}</p>}</div>{action}</div>}{children}</section>}
export function Note({children,tone='neutral'}:{children:ReactNode;tone?:'neutral'|'amber'|'teal'}){return <div className={'note '+tone}><Info size={17}/><div>{children}</div></div>}
export function Loading({text}:{text:string}){return <div className="loading" role="status"><LoaderCircle className="spin" size={23}/><span>{text}</span></div>}
export function Empty({title,body,children}:{title:string;body:string;children?:ReactNode}){return <div className="empty"><div className="empty-icon"><Info size={27}/></div><h3>{title}</h3><p>{body}</p>{children}</div>}
export function Chart({data,layout={},height=330,label='График / График'}:{data:any[];layout?:any;height?:number;label?:string}){
  const ref=useRef<HTMLDivElement>(null);const [error,setError]=useState(false);
  useEffect(()=>{let canceled=false;let plot:any;const node=ref.current;let observer:ResizeObserver|undefined;
    import('plotly.js-dist-min').then(({default:P})=>{plot=P;if(canceled||!node)return;P.react(node,data,{height,paper_bgcolor:'transparent',plot_bgcolor:'transparent',font:{family:'Segoe UI, sans-serif',size:12,color:'#73838c'},margin:{t:20,r:18,b:48,l:55},colorway:colors,xaxis:{gridcolor:'#edf1f2',zeroline:false},yaxis:{gridcolor:'#edf1f2',zeroline:false},legend:{orientation:'h',y:-.22,font:{size:11}},...layout},{responsive:true,displayModeBar:false});observer=new ResizeObserver(()=>{if(!canceled)P.Plots.resize(node)});observer.observe(node)}).catch(()=>setError(true));
    return()=>{canceled=true;observer?.disconnect();if(plot&&node)plot.purge(node)};
  },[JSON.stringify(data),JSON.stringify(layout),height]);
  if(error)return <div className="note amber" role="alert"><AlertCircle size={18}/> График недоступен / График қолжетімсіз</div>;
  return <div className="chart" ref={ref} role="img" aria-label={label} style={{minHeight:height}}/>;
}
export function MetricsTable({rows,selected,t,sd=true}:{rows:any[];selected?:string;t:T;sd?:boolean}){
 const [sort,setSort]=useState('original'),[query,setQuery]=useState('');
 const showThreshold=rows.some(r=>typeof r.threshold==='number');
 const visible=rows.filter(r=>String(r.name).toLowerCase().includes(query.toLowerCase()));
 if(sort!=='original')visible.sort((a,b)=>{
  const x=a.metrics?.[sort],y=b.metrics?.[sort];
  if(!Number.isFinite(x))return Number.isFinite(y)?1:0;if(!Number.isFinite(y))return -1;
  return sort==='brier'?x-y:y-x;
 });
 return <div className="metric-explorer"><div className="metric-controls">
  <label>{t('Найти модель','Модельді табу')}<input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder={t('Название алгоритма','Алгоритм атауы')}/></label>
  <label>{t('Упорядочить по','Реттеу өлшемі')}<select value={sort} onChange={e=>setSort(e.target.value)}><option value="original">{t('Исходный порядок','Бастапқы рет')}</option>{Object.entries(metricNames).map(([key,name])=><option key={key} value={key}>{name}{key==='brier'?' ↑':' ↓'}</option>)}</select></label>
  <span>{visible.length} / {rows.length}</span>
 </div>{sort!=='original'&&<p className="metric-sort-note">{t('Это сортировка отображения. Итоговая модель по-прежнему выбрана по зафиксированному протоколу. Brier: меньше — лучше.','Бұл тек көрсету ретін өзгертеді. Соңғы модель бекітілген хаттама бойынша таңдалған. Brier: төмен болғаны жақсы.')}</p>}
 <div className="table-scroll" tabIndex={0} aria-label={t('Таблица метрик, прокручивается горизонтально','Метрикалар кестесі, көлденең айналдырылады')}><table className="metrics-table"><thead><tr><th>{t('Алгоритм','Алгоритм')}</th>{showThreshold&&<th>{t('Порог','Шек')}</th>}{Object.values(metricNames).map(n=><th key={n}>{n}</th>)}</tr></thead><tbody>{visible.map(r=><tr key={r.name} className={r.name===selected?'selected-row':''}><td><strong>{r.name}</strong>{r.name===selected&&<span className="mini-tag">{t('выбран по протоколу','хаттама бойынша таңдалған')}</span>}</td>{showThreshold&&<td>{fmt(r.threshold)}</td>}{Object.keys(metricNames).map(k=><td key={k}>{fmt(r.metrics?.[k])}{sd&&r.std&&<small>± {fmt(r.std[k])} SD</small>}</td>)}</tr>)}</tbody></table>{!visible.length&&<p role="status">{t('Нет моделей с таким названием.','Мұндай атауы бар модель табылмады.')}</p>}</div></div>;
}
export function ExternalLink({url,children}:{url?:string;children:ReactNode}){return url?<a className="inline-link" href={url} target="_blank" rel="noreferrer noopener">{children}<ArrowUpRight size={15}/></a>:<span>{children}</span>}
