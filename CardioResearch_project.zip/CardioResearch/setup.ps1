﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) { python -m venv .venv }
& '.\.venv\Scripts\python.exe' -m pip install -r requirements-tested.txt
if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить зависимости Python' }
Push-Location frontend
try {
 npm.cmd ci
 if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить зависимости интерфейса' }
 npm.cmd run build
 if ($LASTEXITCODE -ne 0) { throw 'Не удалось собрать интерфейс' }
} finally { Pop-Location }
