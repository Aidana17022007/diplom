import {useEffect, useRef, useState} from 'react';
import {ArrowDownToLine, ArrowRight, CheckCircle2, CircleDashed, ClipboardList, Pause, Play, RotateCcw} from 'lucide-react';
import {Card, Lang, Note, T} from './ui';
import './battle.css';

export default function BattlePrep({lang, onNavigate}: {lang: Lang; onNavigate: (page: string) => void}) {
  const t: T = (ru, kk) => lang === 'kk' ? kk : ru;
  const [checked, setChecked] = useState<string[]>([]);
  const [step, setStep] = useState(0);
  const [minutes, setMinutes] = useState(3);
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);
  const started = useRef(0), accumulated = useRef(0);
  const duration = minutes * 60;
  useEffect(() => {
    if (!running) return;
    started.current = Date.now();
    const tick = () => {
      const next = Math.min(duration, accumulated.current + (Date.now() - started.current) / 1000);
      setElapsed(next);
      if (next >= duration) {accumulated.current = duration; setRunning(false);}
    };
    const timer = window.setInterval(tick, 200);
    return () => window.clearInterval(timer);
  }, [running, duration]);
  const resetTimer = () => {setRunning(false); setElapsed(0); accumulated.current = 0;};
  const toggleTimer = () => {
    if (running) {accumulated.current = Math.min(duration, accumulated.current + (Date.now() - started.current) / 1000); setElapsed(accumulated.current); setRunning(false);}
    else if (elapsed < duration) setRunning(true);
  };
  const items = [
    {id: 'rules', title: t('Официальный регламент','Ресми регламент'), detail: t('Ссылка на анонс или форму; год, дедлайн, критерии, длительность питча и допустимость исследовательского прототипа.','Хабарландыру не өтінім сілтемесі; жыл, мерзім, өлшемдер, питч ұзақтығы және зерттеу прототипін қабылдау шарты.')},
    {id: 'history', title: t('История действующего проекта','Жобаның жұмыс тарихы'), detail: t('Дата начала, команда и подтверждение, что продукт существовал до подготовки к баттлу. Дата файла сама по себе этого не доказывает.','Басталған күні, команда және өнімнің баттлға дайындыққа дейін болғанын растау. Файл күні мұны өздігінен дәлелдемейді.')},
    {id: 'users', title: t('Реальные пользователи и клиенты','Нақты пайдаланушылар мен клиенттер'), detail: t('Кто пользуется продуктом, сколько пользователей и с какого времени. Укажите обезличенные сведения, без данных пациентов.','Өнімді кім, қанша адам және қашаннан бері қолданатынын көрсетіңіз. Пациенттердің жеке деректерін қоспаңыз.')},
    {id: 'sales', title: t('Первые оплаты','Алғашқы төлемдер'), detail: t('За что платили, суммы, даты, число покупателей и вид подтверждения. Бесплатный пилот укажите отдельно.','Не үшін төленгені, сома, күн, сатып алушылар саны және растау түрі. Тегін пилотты бөлек көрсетіңіз.')},
    {id: 'pilot', title: t('Измеренный результат пилота','Пилоттың өлшенген нәтижесі'), detail: t('Выберите задачу и измерьте её до и после: время, ошибки, повторное использование. ML-метрики не заменяют пользу для клиента.','Міндетті таңдап, оған дейінгі және кейінгі уақытты, қателерді, қайта қолдануды өлшеңіз. ML метрикалары клиентке пайданы алмастырмайды.')},
    {id: 'team', title: t('Команда и медицинский эксперт','Команда және медицина сарапшысы'), detail: t('Роли, доступное время, бюджет, участие врача и следующий проверяемый этап развития.','Рөлдер, қолжетімді уақыт, бюджет, дәрігердің қатысуы және келесі тексерілетін даму кезеңі.')},
    {id: 'pitch', title: t('Питч и резервная демонстрация','Питч және резервтік көрсетілім'), detail: t('Проблема → пользователь → продукт → подтверждённые результаты → запрос. Проверьте локальный запуск и приготовьте запись экрана.','Мәселе → пайдаланушы → өнім → расталған нәтиже → сұраныс. Жергілікті іске қосуды тексеріп, экран жазбасын дайындаңыз.')}
  ];
  const steps = [
    {title: t('Покажите исследование','Зерттеуді көрсетіңіз'), time: '00:00–00:30', page: 'models', text: t('Объясните задачу классификации зарегистрированного заболевания. Выберите один набор и покажите реальные метрики, назвав способ проверки.','Тіркелген ауруды жіктеу міндетін түсіндіріңіз. Бір жинақты таңдап, тексеру тәсілін атап, нақты метрикаларды көрсетіңіз.')},
    {title: t('Пройдите основной сценарий','Негізгі сценарийден өтіңіз'), time: '00:30–01:10', page: 'predict', text: t('Откройте «Демопример» и рассчитайте оценку. Скажите, что пример синтетический, а результат относится к сохранённой исследовательской модели.','«Демомысалды» ашып, бағаны есептеңіз. Мысал синтетикалық, нәтиже сақталған зерттеу моделіне қатысты екенін айтыңыз.')},
    {title: t('Объясните результат','Нәтижені түсіндіріңіз'), time: '01:10–01:40', page: 'explain', text: t('После расчёта покажите вклад признаков. Объясните, что это описание ответа модели, а не причинная связь и не назначение лечения.','Есептеуден кейін белгілер үлесін көрсетіңіз. Бұл модель жауабының сипаттамасы екенін, себептік байланыс не ем тағайындау емес екенін түсіндіріңіз.')},
    {title: t('Продемонстрируйте 3D','3D көрсетіңіз'), time: '01:40–02:15', page: 'artery', text: t('Поверните артерию, включите разрез, сравните 0% и 50%. Назовите её отдельной учебной иллюстрацией: геометрия не получена из анкеты.','Артерияны айналдырып, қиманы қосыңыз, 0% және 50% салыстырыңыз. Геометрия сауалнамадан алынбаған бөлек оқу иллюстрациясы екенін айтыңыз.')},
    {title: t('Завершите фактами и запросом','Деректермен және сұраныспен аяқтаңыз'), time: '02:15–03:00', page: 'info', text: t('Назовите ограничения, только подтверждённых клиентов и оплаты, состав команды и следующий шаг. Если пилота нет, прямо обозначьте это и запрос на партнёра.','Шектеулерді, тек расталған клиенттер мен төлемдерді, команданы және келесі қадамды атаңыз. Пилот болмаса, оны және серіктес іздеу сұранысын ашық айтыңыз.')}
  ];
  const exportList = () => {
    const content = [t('CardioResearch — подготовка к MedTech Battle','CardioResearch — MedTech Battle дайындығы'), '',
      t('Допуск к конкурсу не подтверждён. Ниже личные отметки подготовки, а не проверенные доказательства.','Байқауға қатысу расталмаған. Төменде тексерілген дәлелдер емес, жеке дайындық белгілері берілген.'), '',
      ...items.map(item => `${checked.includes(item.id) ? '[x]' : '[ ]'} ${item.title}\n${item.detail}\n`),
      t('Есть в проекте: приложение, сохранённые ML-модели, демо, объяснения, CSV/PDF, RU/KZ, учебная 3D-артерия.','Жобада бар: қосымша, сақталған ML модельдері, демо, түсіндірмелер, CSV/PDF, RU/KZ, артерияның оқу 3D моделі.'), '',
      t('Клиенты, продажи и эффект пилота в предоставленных материалах не подтверждены.','Ұсынылған материалдарда клиенттер, сатылымдар және пилот нәтижесі расталмаған.')].join('\n');
    const url = URL.createObjectURL(new Blob(['\uFEFF' + content], {type: 'text/plain;charset=utf-8'}));
    const a = document.createElement('a'); a.href = url; a.download = `CardioResearch_Battle_${lang}.txt`; a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const remaining = Math.max(0, Math.ceil(duration - elapsed));
  return <div className="battle-prep">
    <section className="battle-banner"><div className="battle-emblem"><ClipboardList size={29}/></div><div><span className="eyebrow">MEDTECH BATTLE</span><h2>{t('От работающего прототипа к заявке','Жұмыс істейтін прототиптен өтінімге дейін')}</h2><p>{t('Техническая основа уже есть. Для участия остаётся подтвердить условия конкурса и факты использования продукта.','Техникалық негіз бар. Қатысу үшін байқау шарттарын және өнімді қолдану деректерін растау қажет.')}</p></div><span className="battle-status">{t('Допуск не подтверждён','Қатысу расталмаған')}</span></section>
    <Note tone="amber">{t('Из предоставленного объявления: 17 ноября, 10 проектов, общий фонд 1 000 000 ₸. Год, дедлайн, критерии и регламент не подтверждены. Новые функции сами по себе не подтверждают клиентов или продажи.','Берілген хабарландыру бойынша: 17 қараша, 10 жоба, жалпы қор 1 000 000 ₸. Жыл, өтінім мерзімі, өлшемдер мен регламент расталмаған. Жаңа функциялар клиенттерді не сатылымды өздігінен растамайды.')}</Note>
    <div className="battle-facts"><article><CheckCircle2 size={22}/><h3>{t('Работающий прототип','Жұмыс істейтін прототип')}</h3><p>{t('Демо, обученные модели, объяснение результатов, сравнение сценариев, CSV/PDF и два языка.','Демо, оқытылған модельдер, нәтижені түсіндіру, сценарийлерді салыстыру, CSV/PDF және екі тіл.')}</p></article><article><CheckCircle2 size={22}/><h3>{t('Медицинская тематика','Медициналық тақырып')}</h3><p>{t('Исследование сердечно-сосудистых заболеваний на BRFSS и UCI. Клиническая готовность не установлена.','BRFSS және UCI бойынша жүрек-қан тамырлары ауруларын зерттеу. Клиникалық дайындық анықталмаған.')}</p></article><article className="pending"><CircleDashed size={22}/><h3>{t('Коммерческое подтверждение','Коммерциялық растау')}</h3><p>{t('В материалах нет подтверждённых клиентов, оплат или измеренного эффекта пилота.','Материалдарда расталған клиенттер, төлемдер немесе пилоттың өлшенген нәтижесі жоқ.')}</p></article></div>
    <Card title={t('Что осталось подготовить','Нені дайындау керек')} subtitle={t('Личные отметки на время открытого раздела. Не меняют подтверждённый статус проекта.','Бөлім ашық тұрған кездегі жеке белгілер. Жобаның расталған мәртебесін өзгертпейді.')} action={<button className="secondary compact" onClick={exportList}><ArrowDownToLine size={15}/>{t('Скачать список','Тізімді жүктеу')}</button>}>
      <div className="battle-progress"><span>{t('Отмечено вами','Сіз белгілеген')}: {checked.length} / {items.length}</span><progress value={checked.length} max={items.length} aria-label={t('Ваш список подготовки','Сіздің дайындық тізіміңіз')}/></div>
      <div className="battle-checklist">{items.map((item, i) => <label key={item.id}><input type="checkbox" checked={checked.includes(item.id)} onChange={e => setChecked(old => e.target.checked ? [...old, item.id] : old.filter(x => x !== item.id))}/><span><strong><small>{String(i + 1).padStart(2, '0')}</small>{item.title}</strong><span>{item.detail}</span></span></label>)}</div>
    </Card>
    <Card title={t('Маршрут демонстрации','Көрсетілім бағыты')} subtitle={t('Пример на 3 минуты для репетиции; это не официальный лимит конкурса.','Жаттығуға арналған 3 минуттық мысал; бұл байқаудың ресми лимиті емес.')}>
      <div className="battle-demo-layout"><div className="battle-steps" role="group" aria-label={t('Этап демонстрации','Көрсетілім кезеңі')}>{steps.map((item, i) => <button key={item.page} className={step === i ? 'active' : ''} aria-pressed={step === i} onClick={() => setStep(i)}><span>{i + 1}</span><div><strong>{item.title}</strong><small>{item.time}</small></div></button>)}</div><div className="battle-step-detail"><span className="eyebrow">{steps[step].time}</span><h3>{steps[step].title}</h3><p>{steps[step].text}</p><button className="primary" onClick={() => onNavigate(steps[step].page)}>{t('Открыть раздел','Бөлімді ашу')}<ArrowRight size={16}/></button></div></div>
    </Card>
    <Card className="battle-timer-card" title={t('Таймер репетиции','Жаттығу таймері')} subtitle={t('Работает, пока этот раздел открыт. Уход со страницы сбрасывает таймер.','Осы бөлім ашық кезде жұмыс істейді. Бөлімнен шыққанда таймер қалпына келеді.')}><div className="battle-timer"><output aria-label={t('Осталось времени','Қалған уақыт')}>{Math.floor(remaining / 60).toString().padStart(2, '0')}:{(remaining % 60).toString().padStart(2, '0')}</output><label>{t('Минут','Минут')}<select aria-label={t('Длительность репетиции','Жаттығу ұзақтығы')} value={minutes} disabled={running} onChange={e => {setMinutes(Number(e.target.value)); resetTimer();}}>{[2, 3, 5, 7].map(n => <option key={n} value={n}>{n}</option>)}</select></label><button className="primary" disabled={remaining === 0} onClick={toggleTimer}>{running ? <Pause size={16}/> : <Play size={16}/>} {running ? t('Пауза','Кідірту') : t('Старт','Бастау')}</button><button className="secondary" onClick={resetTimer}><RotateCcw size={16}/>{t('Сбросить','Қалпына келтіру')}</button>{remaining === 0 && <span role="status">{t('Время завершено','Уақыт аяқталды')}</span>}</div></Card>
  </div>;
}
