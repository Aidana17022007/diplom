"""Package the original diploma plus this committed frontend and diagnostics.

Never overwrites archives, models, original research reports or draft documents.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def main():
    site = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    original, destination = args.archive.resolve(), args.destination.resolve()
    if destination.exists():
        raise FileExistsError(f'Preserve existing archive: {destination}')
    version = json.loads((site / 'package.json').read_text(encoding='utf-8'))['version']
    if version != '2.7.0':
        raise ValueError('This overlay was verified for release 2.7.0')
    if subprocess.check_output(['git', '-C', str(site), 'status', '--porcelain']).strip():
        raise RuntimeError('Commit completed source before packaging')
    tracked = subprocess.check_output(['git', '-C', str(site), 'ls-files', '-z']).decode().split('\0')
    topic = json.loads((site / 'data/thesis-topic.json').read_text(encoding='utf-8'))
    release = '## Тема диплома\n\n' + '\n'.join(f'- {language.upper()}: {title}' for language,title in topic['titles'].items()) + '\n\n' + topic['scope']['ru'] + '\n\n' + '''## Обновление 2.7 — интерфейс, сравнение моделей и исследование порога

- Обновлены навигация, клавиатурный поиск, мобильное меню и читаемость интерфейса.
- В таблицах доступны наборы метрик, сортировка и сравнение двух моделей с разностями значений.
- Лаборатория порогов использует точный сохранённый порог BRFSS как эталон; сравнивает пропуски, ложные срабатывания и метрики на одной валидационной выборке.
- В 3D добавлены интерактивный продольный профиль, подсветка выбранного слоя и ракурс сверху. На паузе сцена перерисовывается по изменениям.
- Модели, вероятности и исследовательские результаты не переобучались. Основной текст диплома в этом выпуске не редактируется.

### Возможности предыдущего выпуска

- В 3D-артерии можно перемещать сечение вдоль сосуда, сравнивать его с исходным и видеть локальные диаметр, площадь и потерю площади. Геометрия не связана с оценкой ML.
- В разделе диплома есть рабочая структура трёх глав: задачи, готовые материалы и оставшаяся работа над рукописью.
- Пользовательская статья Atherosclerosis о сосудистых факторах и деменции добавлена в библиотеку. Через PubMed проверена аннотация; полный текст не прочитан. Это теоретический контекст, а не данные для обучения.

- Новый раздел «Диагностика модели»: 19 метрик, разбор ошибок, сравнение с простыми ориентирами, калибровка с числом наблюдений и условными интервалами Wilson, распределение вероятностей и CSV/JSON.
- Дополнительный ретроспективный опыт: фиксированная UCI Random Forest проверена отдельно на Hungary (294), Switzerland (123) и VA (200). Учтены пропуски, нули и различия состава выборок. Это исследовательская оценка переноса, не клиническая валидация.
- Модели и пороги сохранены. Основные метрики сверены с исходными отчётами. UCI OOF, среднее внешней CV и результаты других центров обозначены отдельно.
- Интерфейс RU/KZ, 3D-артерия, сценарии и раздел готовности диплома сохранены. Новые агрегированные API работают и в локальном Python-приложении.
- Исходные модели и прежние исследовательские отчёты сохранены; добавлены reports/evaluation.json и reports/transfer.json. Воспроизведение описано в deployment/cardio-site/docs/EVALUATION.md.
- Прежние PDF и HTML в output сохранены как черновики. Текст диплома и описание новых опытов требуют авторской актуализации; обновление приложения не подтверждает готовность рукописи к сдаче.

'''
    root = 'CardioResearch/'
    with zipfile.ZipFile(original) as source, zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for entry in source.infolist():
            if entry.filename.startswith((root+'frontend/', root+'deployment/cardio-site/')):
                continue
            payload = source.read(entry)
            if entry.filename == root+'README.md':
                lines = payload.decode('utf-8-sig').splitlines(keepends=True)
                if not lines or lines[0].strip() != '# CardioResearch':
                    raise ValueError('Unexpected README header')
                payload = ('# CardioResearch\n\n'+release+''.join(lines[1:])).encode('utf-8')
            elif entry.filename == root+'cardio/api.py':
                text = payload.decode('utf-8-sig')
                marker = "dist=ROOT/'frontend'/'dist'"
                if text.count(marker) != 1:
                    raise ValueError('Unexpected API layout; do not silently skip route registration')
                text = text.replace(marker, 'from .evaluation import register_evaluation_routes\nregister_evaluation_routes(app, REPORTS)\n\n'+marker)
                text = text.replace("version='2.0.0'", f"version='{version}'")
                # Preserve the existing library and add reviewed references separately.
                library_start = text.index('def library():')
                library_end = text.index("@app.get('/api/research-export/{ds}')", library_start)
                library_block = text[library_start:library_end]
                if library_block.count("    return {'books':public_books") != 1:
                    raise ValueError('Unexpected library route; refuse incomplete local overlay')
                library_block = library_block.replace('def library():', 'def library():\n    from .literature import with_literature_additions')
                library_block = library_block.replace("    return {'books':public_books", "    result = {'books':public_books")
                library_block = library_block.rstrip() + "\n    return with_literature_additions(result, optional_report('literature-additions.json') or {})\n\n\n"
                text = text[:library_start] + library_block + text[library_end:]
                compile(text, 'cardio/api.py', 'exec')
                payload = text.encode('utf-8')
            output.writestr(entry.filename, payload)
        output.write(site/'python/cardio/evaluation.py', root+'cardio/evaluation.py')
        output.write(site/'python/cardio/literature.py', root+'cardio/literature.py')
        for name in ['evaluation', 'transfer', 'thesis-topic', 'literature-additions']:
            output.write(site/f'data/{name}.json', root+f'reports/{name}.json')
        for name in filter(None, tracked):
            output.write(site/name, root+'deployment/cardio-site/'+name)
            if name.startswith('client/'):
                output.write(site/name, root+'frontend/'+name[len('client/'):])
        for path in (site/'client/dist').rglob('*'):
            if path.is_file():
                output.write(path, root+'frontend/dist/'+path.relative_to(site/'client/dist').as_posix())
    with zipfile.ZipFile(original) as source, zipfile.ZipFile(destination) as result:
        assert result.testzip() is None
        assert len(result.namelist()) == len(set(result.namelist()))
        preserved = 0
        for name in source.namelist():
            if name.startswith((root+'models/', root+'reports/', root+'output/')):
                assert hashlib.sha256(source.read(name)).digest() == hashlib.sha256(result.read(name)).digest(), name
                preserved += 1
        for name in ['cardio/evaluation.py', 'reports/evaluation.json', 'reports/transfer.json', 'frontend/src/EvaluationLab.tsx', 'frontend/dist/index.html']:
            assert root+name in result.namelist(), name
        assert 'register_evaluation_routes(app, REPORTS)' in result.read(root+'cardio/api.py').decode()
        assert "return with_literature_additions(result, optional_report('literature-additions.json') or {})" in result.read(root+'cardio/api.py').decode()
    print(json.dumps({'archive':str(destination), 'version':version, 'bytes':destination.stat().st_size,
                      'entries':len(result.namelist()), 'preserved_original_models_reports_drafts':preserved}, ensure_ascii=False))


if __name__ == '__main__':
    main()
