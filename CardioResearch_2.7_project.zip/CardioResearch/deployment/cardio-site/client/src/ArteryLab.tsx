import {lazy, Suspense, useEffect, useState} from 'react';
import {ArrowUpRight, Box, Move, Pause, Play, RotateCcw, Scissors} from 'lucide-react';
import {Card, Lang, Note, T} from './ui';
import {clampNarrowing, clampSectionPosition, HALF_ARTERY_LENGTH, sectionMetrics} from './arteryGeometry';
import ArteryProfile from './ArteryProfile';
import './artery.css';

const ArteryScene = lazy(() => import('./ArteryScene'));

export default function ArteryLab({lang}: {lang: Lang}) {
  const t: T = (ru, kk) => lang === 'kk' ? kk : ru;
  const [narrowing, setNarrowing] = useState(40);
  const [sectionPosition, setSectionPosition] = useState(0);
  const [cutaway, setCutaway] = useState(true);
  const [moving, setMoving] = useState(false);
  const [reset, setReset] = useState(0);
  const [view, setView] = useState<'side' | 'end' | 'top'>('side');
  const [topic, setTopic] = useState(1);
  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    const stop = () => {if (query.matches) setMoving(false);};
    query.addEventListener('change', stop); return () => query.removeEventListener('change', stop);
  }, []);
  const resetAll = () => {setNarrowing(40); setSectionPosition(0); setCutaway(true); setMoving(false); setView('side'); setTopic(1); setReset(n => n + 1);};
  const topics = [
    {name: t('Стенка артерии','Артерия қабырғасы'), text: t('Розовая оболочка показывает стенку сосуда. Её слои и размеры здесь упрощены для наглядности.','Қызғылт қабық тамыр қабырғасын көрсетеді. Қабаттары мен өлшемдері көрнекілік үшін жеңілдетілген.'), color: 'wall'},
    {name: t('Бляшка','Түйіндақ'), text: t('При атеросклерозе в стенке артерии накапливается бляшка. Здесь она выделена золотым и условно расположена по окружности.','Атеросклероз кезінде артерия қабырғасында түйіндақ жиналады. Мұнда ол алтын түспен көрсетіліп, шартты түрде шеңбер бойымен орналасқан.'), color: 'plaque'},
    {name: t('Просвет','Тамыр қуысы'), text: t('Просвет — внутреннее пространство сосуда. Перемещайте ползунок и сравнивайте, как меняются диаметр и площадь условного круглого сечения.','Қуыс — тамырдың ішкі кеңістігі. Жүгірткіні жылжытып, шартты дөңгелек қиманың диаметрі мен ауданы қалай өзгеретінін салыстырыңыз.'), color: 'lumen'}
  ];
  const section = sectionMetrics(sectionPosition, narrowing);
  return <div className="artery-lab">
    <div className="artery-intro"><span className="artery-kicker"><Box size={15}/> {t('ИНТЕРАКТИВНЫЙ АТЛАС','ИНТЕРАКТИВТІ АТЛАС')}</span><h2>{t('Загляните внутрь артерии','Артерияның ішіне үңіліңіз')}</h2><p>{t('Исследуйте стенку, бляшку и просвет в объёме. Меняйте геометрию и сравнивайте поперечное сечение.','Қабырға, түйіндақ және қуысты көлемді түрде зерттеңіз. Геометрияны өзгертіп, көлденең қиманы салыстырыңыз.')}</p></div>
    <Note tone="teal">{t('Учебная схема атеросклероза. Это не снимок пациента: сужение задаётся вручную и не связано с вероятностью, рассчитанной ML-моделью.','Атеросклероздың оқу сызбасы. Бұл пациенттің суреті емес: тарылу қолмен беріледі және ML моделі есептеген ықтималдықпен байланысты емес.')}</Note>
    <div className="artery-workbench">
      <section className="artery-stage" aria-label={t('Объёмная модель','Көлемді модель')}>
        <div className="artery-stage-top"><span><span className="status-dot"/> {t('Артерия · условная геометрия','Артерия · шартты геометрия')}</span><span className="artery-model-badge">3D</span></div>
        <Suspense fallback={<div className="artery-loading" role="status">{t('Загрузка 3D…','3D жүктелуде…')}</div>}><ArteryScene narrowing={narrowing} sectionPosition={sectionPosition} cutaway={cutaway} moving={moving} reset={reset} view={view} highlight={topics[topic].color as 'wall'|'plaque'|'lumen'} t={t}/></Suspense>
        <div className="artery-legend" role="group" aria-label={t('Выделить часть модели','Модель бөлігін ерекшелеу')}>{topics.map((x,i) => <button key={x.color} aria-pressed={topic===i} onClick={()=>setTopic(i)}><i className={x.color}/>{x.name}</button>)}<span><i className="blood"/>{t('Условные частицы','Шартты бөлшектер')}</span><span><i className="section-marker"/>{t('Выбранное сечение','Таңдалған қима')}</span></div>
        <ArteryProfile narrowing={narrowing} position={sectionPosition} onChange={setSectionPosition} t={t}/>
        <div className="artery-scene-tools"><button className={cutaway ? 'selected' : ''} aria-pressed={cutaway} onClick={() => setCutaway(x => !x)}><Scissors size={15}/>{t('Разрез','Қима')}</button><button aria-pressed={moving} onClick={() => setMoving(x => !x)}>{moving ? <Pause size={15}/> : <Play size={15}/>} {moving ? t('Пауза','Кідірту') : t('Движение частиц','Бөлшектер қозғалысы')}</button><button onClick={resetAll}><RotateCcw size={15}/>{t('Сбросить','Қалпына келтіру')}</button></div>
        <p className="artery-hint"><Move size={14}/>{t('Перетащите для вращения · кнопки + / − для масштаба · доступны клавиши со стрелками','Айналдыру үшін сүйреңіз · масштаб үшін + / − батырмалары · бағыттау пернелері де жұмыс істейді')}</p>
      </section>
      <Card className="artery-controls" title={t('Геометрия сужения','Тарылу геометриясы')}>
        <label className="artery-slider-label" htmlFor="artery-narrowing"><span>{t('Максимальное сужение диаметра','Диаметрдің ең үлкен тарылуы')}</span><output htmlFor="artery-narrowing">{narrowing}<small>%</small></output></label>
        <input id="artery-narrowing" type="range" min="0" max="80" step="1" value={narrowing} onChange={e => setNarrowing(clampNarrowing(Number(e.target.value)))}/>
        <div className="artery-range-labels"><span>0%</span><span>80%</span></div>
        <div className="artery-presets" role="group" aria-label={t('Примеры геометрии','Геометрия мысалдары')}>{[0, 25, 50, 75].map(n => <button key={n} aria-pressed={narrowing === n} className={narrowing === n ? 'selected' : ''} onClick={() => setNarrowing(n)}>{n}%</button>)}</div>
        <p className="artery-control-note">{t('Примеры формы, а не клинические стадии. Ползунок изменяет диаметр в самом узком месте.','Клиникалық сатылар емес, пішін мысалдары. Жүгірткі ең тар жердегі диаметрді өзгертеді.')}</p>
        <div className="artery-section-position">
          <label htmlFor="artery-section-position"><span>{t('Положение сечения','Қима орны')}</span><output htmlFor="artery-section-position">x = {sectionPosition.toFixed(1)}</output></label>
          <input id="artery-section-position" type="range" min={-HALF_ARTERY_LENGTH} max={HALF_ARTERY_LENGTH} step="0.1" value={sectionPosition} onChange={e=>setSectionPosition(clampSectionPosition(Number(e.target.value)))} aria-valuetext={t(`Положение ${sectionPosition.toFixed(1)}, условные единицы; местное сужение ${section.narrowingPercent.toFixed(1)}%.`,`Орны ${sectionPosition.toFixed(1)}, шартты бірлік; жергілікті тарылу ${section.narrowingPercent.toFixed(1)}%.`)}/>
          <div className="artery-range-labels"><span>−3.6</span><span>{t('Центр: 0','Ортасы: 0')}</span><span>+3.6</span></div>
          <button className="artery-center-reset" onClick={()=>setSectionPosition(0)}><RotateCcw size={13}/>{narrowing>0?t('Самое узкое место','Ең тар жер'):t('К центру','Ортасына')}</button>
          <p>{t('Голубое кольцо в 3D отмечает этот срез. Координата условная, не миллиметры.','3D-дегі көгілдір сақина осы қиманы белгілейді. Координата шартты, миллиметр емес.')}</p>
        </div>
        <div className="artery-section-comparison">
          <figure><svg viewBox="0 0 180 180" role="img" aria-label={t('Исходное сечение без сужения: диаметр и площадь 100%.','Тарылусыз бастапқы қима: диаметрі мен ауданы 100%.')}><circle cx="90" cy="90" r="76" fill="#cf7b87"/><circle cx="90" cy="90" r="63" fill="#173d48"/><path d="M27 90H153" stroke="#fff9" strokeWidth="1" strokeDasharray="3 4"/></svg><figcaption>{t('Без сужения','Тарылусыз')}<small>{t('Исходная геометрия','Бастапқы геометрия')}</small></figcaption></figure>
          <figure><svg viewBox="0 0 180 180" role="img" aria-label={t(`Выбранное сечение x=${sectionPosition.toFixed(1)}: местное сужение ${section.narrowingPercent.toFixed(1)}%, площадь просвета ${section.areaPercent.toFixed(1)}% от исходной.`,`Таңдалған қима x=${sectionPosition.toFixed(1)}: жергілікті тарылу ${section.narrowingPercent.toFixed(1)}%, қуыс ауданы бастапқының ${section.areaPercent.toFixed(1)}%.`)}><circle cx="90" cy="90" r="76" fill="#cf7b87"/><circle cx="90" cy="90" r="63" fill="#e7b961"/><circle cx="90" cy="90" r={63*section.radius} fill="#173d48"/><path d="M27 90H153" stroke="#fff9" strokeWidth="1" strokeDasharray="3 4"/><circle cx="90" cy="90" r="63" fill="none" stroke="#fff9" strokeWidth="1" strokeDasharray="3 4"/></svg><figcaption>{t('Выбранное сечение','Таңдалған қима')}<small>x = {sectionPosition.toFixed(1)}</small></figcaption></figure>
        </div>
        <div className="artery-local-metrics" aria-live="polite"><div><span>{t('Диаметр среза','Қима диаметрі')}</span><strong>{section.diameterPercent.toFixed(1)}<small>%</small></strong></div><div><span>{t('Площадь просвета','Қуыс ауданы')}</span><strong>{section.areaPercent.toFixed(1)}<small>%</small></strong></div><div><span>{t('Потеря площади','Ауданның азаюы')}</span><strong>{section.areaLossPercent.toFixed(1)}<small>%</small></strong></div></div>
        <p className="artery-formula">A(x) / A₀ = [d(x) / d₀]²<br/>{t('Диаметр и площадь — относительно исходного сечения. Потеря площади = 100% − оставшаяся площадь. Эти числа относятся к выбранному срезу; ползунок сверху задаёт максимальное сужение в центре.','Диаметр мен аудан бастапқы қимаға қатысты. Ауданның азаюы = 100% − қалған аудан. Бұл сандар таңдалған қимаға қатысты; жоғарғы жүгірткі ортасындағы ең үлкен тарылуды белгілейді.')}</p>
        <div className="artery-view-switch" role="group" aria-label={t('Ракурс камеры','Камера көрінісі')}><button aria-pressed={view === 'side'} onClick={() => {setView('side'); setReset(n => n + 1);}}>{t('Сбоку','Бүйірінен')}</button><button aria-pressed={view === 'top'} onClick={() => {setView('top'); setReset(n => n + 1);}}>{t('Сверху','Үстінен')}</button><button aria-pressed={view === 'end'} onClick={() => {setView('end'); setReset(n => n + 1);}}>{t('С торца','Ұшынан')}</button></div>
      </Card>
    </div>
    <section className="artery-explainer" id="artery-description"><div role="group" aria-label={t('Что показано на модели','Модельде не көрсетілген')}>{topics.map((x, i) => <button key={x.color} className={topic === i ? 'selected' : ''} aria-pressed={topic === i} onClick={() => setTopic(i)}><i className={x.color}/>{x.name}</button>)}</div><h3>{topics[topic].name}</h3><p>{topics[topic].text}</p></section>
    <div className="artery-footnote"><p>{t('Масштаб и форма упрощены. Движение частиц — иллюстрация: скорость, давление и объёмный кровоток не рассчитываются. Процент сужения не означает вероятность инфаркта.','Масштаб пен пішін жеңілдетілген. Бөлшектер қозғалысы — иллюстрация: жылдамдық, қысым және қан ағынының көлемі есептелмейді. Тарылу пайызы инфаркт ықтималдығын білдірмейді.')}</p><a href="https://www.nhlbi.nih.gov/health/atherosclerosis" target="_blank" rel="noreferrer noopener">{t('Об атеросклерозе · NHLBI / NIH','Атеросклероз туралы · NHLBI / NIH')}<ArrowUpRight size={15}/></a></div>
  </div>;
}
