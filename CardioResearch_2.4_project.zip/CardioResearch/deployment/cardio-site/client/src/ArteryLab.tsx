import {lazy, Suspense, useEffect, useState} from 'react';
import {ArrowUpRight, Box, Move, Pause, Play, RotateCcw, Scissors} from 'lucide-react';
import {Card, Lang, Note, T} from './ui';
import {clampNarrowing, remainingArea} from './arteryGeometry';
import './artery.css';

const ArteryScene = lazy(() => import('./ArteryScene'));

export default function ArteryLab({lang}: {lang: Lang}) {
  const t: T = (ru, kk) => lang === 'kk' ? kk : ru;
  const [narrowing, setNarrowing] = useState(40);
  const [cutaway, setCutaway] = useState(true);
  const [moving, setMoving] = useState(false);
  const [reset, setReset] = useState(0);
  const [view, setView] = useState<'side' | 'end'>('side');
  const [topic, setTopic] = useState(1);
  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    const stop = () => {if (query.matches) setMoving(false);};
    query.addEventListener('change', stop); return () => query.removeEventListener('change', stop);
  }, []);
  const resetAll = () => {setNarrowing(40); setCutaway(true); setMoving(false); setView('side'); setReset(n => n + 1);};
  const topics = [
    {name: t('Стенка артерии','Артерия қабырғасы'), text: t('Розовая оболочка показывает стенку сосуда. Её слои и размеры здесь упрощены для наглядности.','Қызғылт қабық тамыр қабырғасын көрсетеді. Қабаттары мен өлшемдері көрнекілік үшін жеңілдетілген.'), color: 'wall'},
    {name: t('Бляшка','Түйіндақ'), text: t('При атеросклерозе в стенке артерии накапливается бляшка. Здесь она выделена золотым и условно расположена по окружности.','Атеросклероз кезінде артерия қабырғасында түйіндақ жиналады. Мұнда ол алтын түспен көрсетіліп, шартты түрде шеңбер бойымен орналасқан.'), color: 'plaque'},
    {name: t('Просвет','Тамыр қуысы'), text: t('Просвет — внутреннее пространство сосуда. Перемещайте ползунок и сравнивайте, как меняются диаметр и площадь условного круглого сечения.','Қуыс — тамырдың ішкі кеңістігі. Жүгірткіні жылжытып, шартты дөңгелек қиманың диаметрі мен ауданы қалай өзгеретінін салыстырыңыз.'), color: 'lumen'}
  ];
  const area = remainingArea(narrowing);
  return <div className="artery-lab">
    <div className="artery-intro"><span className="artery-kicker"><Box size={15}/> {t('ИНТЕРАКТИВНЫЙ АТЛАС','ИНТЕРАКТИВТІ АТЛАС')}</span><h2>{t('Загляните внутрь артерии','Артерияның ішіне үңіліңіз')}</h2><p>{t('Исследуйте стенку, бляшку и просвет в объёме. Меняйте геометрию и сравнивайте поперечное сечение.','Қабырға, түйіндақ және қуысты көлемді түрде зерттеңіз. Геометрияны өзгертіп, көлденең қиманы салыстырыңыз.')}</p></div>
    <Note tone="teal">{t('Учебная схема атеросклероза. Это не снимок пациента: сужение задаётся вручную и не связано с вероятностью, рассчитанной ML-моделью.','Атеросклероздың оқу сызбасы. Бұл пациенттің суреті емес: тарылу қолмен беріледі және ML моделі есептеген ықтималдықпен байланысты емес.')}</Note>
    <div className="artery-workbench">
      <section className="artery-stage" aria-label={t('Объёмная модель','Көлемді модель')}>
        <div className="artery-stage-top"><span><span className="status-dot"/> {t('Артерия · условная геометрия','Артерия · шартты геометрия')}</span><span className="artery-model-badge">3D</span></div>
        <Suspense fallback={<div className="artery-loading" role="status">{t('Загрузка 3D…','3D жүктелуде…')}</div>}><ArteryScene narrowing={narrowing} cutaway={cutaway} moving={moving} reset={reset} view={view} t={t}/></Suspense>
        <div className="artery-legend">{topics.map(x => <span key={x.color}><i className={x.color}/>{x.name}</span>)}<span><i className="blood"/>{t('Условные частицы','Шартты бөлшектер')}</span></div>
        <div className="artery-scene-tools"><button className={cutaway ? 'selected' : ''} aria-pressed={cutaway} onClick={() => setCutaway(x => !x)}><Scissors size={15}/>{t('Разрез','Қима')}</button><button aria-pressed={moving} onClick={() => setMoving(x => !x)}>{moving ? <Pause size={15}/> : <Play size={15}/>} {moving ? t('Пауза','Кідірту') : t('Движение частиц','Бөлшектер қозғалысы')}</button><button onClick={resetAll}><RotateCcw size={15}/>{t('Сбросить','Қалпына келтіру')}</button></div>
        <p className="artery-hint"><Move size={14}/>{t('Перетащите для вращения · кнопки + / − для масштаба · доступны клавиши со стрелками','Айналдыру үшін сүйреңіз · масштаб үшін + / − батырмалары · бағыттау пернелері де жұмыс істейді')}</p>
      </section>
      <Card className="artery-controls" title={t('Геометрия сужения','Тарылу геометриясы')}>
        <label className="artery-slider-label" htmlFor="artery-narrowing"><span>{t('Сужение диаметра','Диаметрдің тарылуы')}</span><output htmlFor="artery-narrowing">{narrowing}<small>%</small></output></label>
        <input id="artery-narrowing" type="range" min="0" max="80" step="1" value={narrowing} onChange={e => setNarrowing(clampNarrowing(Number(e.target.value)))}/>
        <div className="artery-range-labels"><span>0%</span><span>80%</span></div>
        <div className="artery-presets" role="group" aria-label={t('Примеры геометрии','Геометрия мысалдары')}>{[0, 25, 50, 75].map(n => <button key={n} aria-pressed={narrowing === n} className={narrowing === n ? 'selected' : ''} onClick={() => setNarrowing(n)}>{n}%</button>)}</div>
        <p className="artery-control-note">{t('Примеры формы, а не клинические стадии. Ползунок изменяет диаметр в самом узком месте.','Клиникалық сатылар емес, пішін мысалдары. Жүгірткі ең тар жердегі диаметрді өзгертеді.')}</p>
        <div className="artery-cross-section"><svg viewBox="0 0 180 180" role="img" aria-label={t(`Поперечное сечение: сужение диаметра ${narrowing}%, площадь просвета ${area.toFixed(1)}% от исходной.`,`Көлденең қима: диаметр тарылуы ${narrowing}%, қуыс ауданы бастапқының ${area.toFixed(1)}%.`)}><circle cx="90" cy="90" r="76" fill="#cf7b87"/><circle cx="90" cy="90" r="63" fill="#e7b961"/><circle cx="90" cy="90" r={63 * (1 - narrowing / 100)} fill="#173d48"/><path d="M27 90H153" stroke="#fff9" strokeWidth="1" strokeDasharray="3 4"/><circle cx="90" cy="90" r="63" fill="none" stroke="#fff9" strokeWidth="1" strokeDasharray="3 4"/></svg><div><span>{t('Площадь просвета','Қуыс ауданы')}</span><strong>{area.toFixed(1)}<small>%</small></strong><small>{t('от исходной площади','бастапқы ауданнан')}</small></div></div>
        <p className="artery-formula">A / A₀ = (1 − s / 100)²<br/>{t('s — сужение диаметра, %. Только для этой круглой геометрии.','s — диаметрдің тарылуы, %. Тек осы дөңгелек геометрия үшін.')}</p>
        <div className="artery-view-switch" role="group" aria-label={t('Ракурс камеры','Камера көрінісі')}><button aria-pressed={view === 'side'} onClick={() => {setView('side'); setReset(n => n + 1);}}>{t('Сбоку','Бүйірінен')}</button><button aria-pressed={view === 'end'} onClick={() => {setView('end'); setReset(n => n + 1);}}>{t('С торца','Ұшынан')}</button></div>
      </Card>
    </div>
    <section className="artery-explainer" id="artery-description"><div role="group" aria-label={t('Что показано на модели','Модельде не көрсетілген')}>{topics.map((x, i) => <button key={x.color} className={topic === i ? 'selected' : ''} aria-pressed={topic === i} onClick={() => setTopic(i)}><i className={x.color}/>{x.name}</button>)}</div><h3>{topics[topic].name}</h3><p>{topics[topic].text}</p></section>
    <div className="artery-footnote"><p>{t('Масштаб и форма упрощены. Движение частиц — иллюстрация: скорость, давление и объёмный кровоток не рассчитываются. Процент сужения не означает вероятность инфаркта.','Масштаб пен пішін жеңілдетілген. Бөлшектер қозғалысы — иллюстрация: жылдамдық, қысым және қан ағынының көлемі есептелмейді. Тарылу пайызы инфаркт ықтималдығын білдірмейді.')}</p><a href="https://www.nhlbi.nih.gov/health/atherosclerosis" target="_blank" rel="noreferrer noopener">{t('Об атеросклерозе · NHLBI / NIH','Атеросклероз туралы · NHLBI / NIH')}<ArrowUpRight size={15}/></a></div>
  </div>;
}
