// Normalized educational geometry, independent of questionnaires and ML outputs.
export const MAX_NARROWING = 80;

export function clampNarrowing(value: number): number {
  return Math.max(0, Math.min(MAX_NARROWING, Number.isFinite(value) ? value : 0));
}

export function lumenRadius(x: number, narrowing: number): number {
  const bump = Math.pow(Math.max(0, 1 - (x / 2.6) ** 2), 2);
  return 1 - clampNarrowing(narrowing) / 100 * bump;
}

export function remainingArea(narrowing: number): number {
  return (1 - clampNarrowing(narrowing) / 100) ** 2 * 100;
}
