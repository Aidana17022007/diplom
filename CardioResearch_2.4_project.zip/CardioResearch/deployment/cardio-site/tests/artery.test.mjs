import test from 'node:test';
import assert from 'node:assert/strict';
import {build} from 'esbuild';

const bundle = await build({entryPoints: ['client/src/arteryGeometry.ts'], bundle: true, format: 'esm', write: false});
const {clampNarrowing, remainingArea, lumenRadius} = await import('data:text/javascript;base64,' + Buffer.from(bundle.outputFiles[0].text).toString('base64'));

test('diameter narrowing is distinct from area loss', () => {
  assert.equal(remainingArea(0), 100);
  assert.equal(remainingArea(50), 25);
  assert.ok(Math.abs(remainingArea(80) - 4) < 1e-10);
});
test('the central radius matches the displayed diameter; ends remain open', () => {
  for (const n of [0, 25, 40, 50, 75, 80]) {
    assert.ok(Math.abs(lumenRadius(0, n) - (1 - n / 100)) < 1e-10);
    assert.equal(lumenRadius(-3.6, n), 1);
    assert.equal(lumenRadius(3.6, n), 1);
    for (let x = -3.6; x <= 3.6; x += .05) {
      const radius = lumenRadius(x, n);
      assert.ok(radius >= .199999 && radius <= 1);
      assert.ok(Math.abs(radius - lumenRadius(-x, n)) < 1e-10);
    }
  }
});
test('invalid and out-of-range geometry inputs cannot collapse the lumen', () => {
  assert.equal(clampNarrowing(NaN), 0);
  assert.equal(clampNarrowing(Infinity), 0);
  assert.equal(clampNarrowing(-1), 0);
  assert.equal(clampNarrowing(120), 80);
});
