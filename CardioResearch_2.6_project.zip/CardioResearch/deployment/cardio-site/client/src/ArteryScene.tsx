import {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {clampSectionPosition, lumenRadius} from './arteryGeometry';
import type {T} from './ui';

type Props = {narrowing: number; sectionPosition: number; cutaway: boolean; moving: boolean; reset: number; view: 'side' | 'end'; t: T};
type SceneApi = {update: (n: number, cut: boolean) => void; section: (position: number) => void; motion: boolean; reset: (view: Props['view']) => void};

function surface(point: (u: number, v: number) => number[], nu = 64, nv = 72) {
  const positions: number[] = [], indices: number[] = [];
  for (let i = 0; i <= nu; i++) for (let j = 0; j <= nv; j++) positions.push(...point(i / nu, j / nv));
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
    const a = i * (nv + 1) + j, b = a + nv + 1;
    indices.push(a, b, a + 1, b, b + 1, a + 1);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

export default function ArteryScene({narrowing, sectionPosition, cutaway, moving, reset, view, t}: Props) {
  const host = useRef<HTMLDivElement>(null);
  const api = useRef<SceneApi | null>(null);
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const container = host.current!;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({antialias: true, alpha: true}); }
    catch { setFailed(true); return; }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x102e38, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.setAttribute('aria-hidden', 'true');
    container.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(37, 1, 0.1, 100);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.enablePan = false;
    controls.minDistance = 5;
    controls.maxDistance = 19;
    // Scroll the page normally; use the explicit zoom controls for the scene.
    controls.enableZoom = false;
    scene.add(new THREE.HemisphereLight(0xe8f8ff, 0x5d293e, 2.6));
    const key = new THREE.DirectionalLight(0xfff4df, 3.2); key.position.set(0, 5, 6); scene.add(key);
    const rim = new THREE.DirectionalLight(0x77d4cf, 2); rim.position.set(-3, -2, -4); scene.add(rim);
    const vessel = new THREE.Group(); scene.add(vessel);
    // A separate marker follows the chosen cross-section; changing its position
    // does not rebuild vessel meshes or create another WebGL context.
    const sectionMarker = new THREE.Group(); scene.add(sectionMarker);
    const sectionRingGeometry = new THREE.TorusGeometry(1.32, .018, 8, 96);
    const sectionPlaneGeometry = new THREE.CircleGeometry(1.29, 72);
    const sectionRingMaterial = new THREE.MeshBasicMaterial({color:0x9de6ee, transparent:true, opacity:.95, depthTest:false, depthWrite:false});
    const sectionPlaneMaterial = new THREE.MeshBasicMaterial({color:0x7fd6e3, transparent:true, opacity:.10, side:THREE.DoubleSide, depthWrite:false});
    const sectionRing = new THREE.Mesh(sectionRingGeometry, sectionRingMaterial);
    const sectionPlane = new THREE.Mesh(sectionPlaneGeometry, sectionPlaneMaterial);
    sectionRing.rotation.y = sectionPlane.rotation.y = Math.PI / 2;
    sectionRing.renderOrder = 3; sectionPlane.renderOrder = 2;
    sectionMarker.add(sectionRing, sectionPlane);
    sectionMarker.position.x = clampSectionPosition(sectionPosition);
    const wall = new THREE.MeshStandardMaterial({color: 0xb44c64, roughness: .59, side: THREE.DoubleSide});
    const lining = new THREE.MeshStandardMaterial({color: 0xe68b93, roughness: .5, side: THREE.DoubleSide});
    const cutWall = new THREE.MeshStandardMaterial({color: 0xf4b3aa, roughness: .75, side: THREE.DoubleSide});
    const plaque = new THREE.MeshStandardMaterial({color: 0xe6b45f, roughness: .68, side: THREE.DoubleSide});
    const plaqueCut = new THREE.MeshStandardMaterial({color: 0xffd58c, roughness: .8, side: THREE.DoubleSide});
    const cellMaterial = new THREE.MeshStandardMaterial({color: 0xf05f69, roughness: .38});
    const cellGeometry = new THREE.TorusGeometry(.095, .046, 8, 16);
    const cells = Array.from({length: 24}, (_, i) => {
      const cell = new THREE.Mesh(cellGeometry, cellMaterial);
      cell.rotation.set(i * .71, i * 1.37, i * .41);
      scene.add(cell);
      return cell;
    });
    let currentNarrowing = narrowing;
    const draw = () => renderer.render(scene, camera);
    function rebuild(n: number, cut: boolean) {
      currentNarrowing = n;
      vessel.children.forEach(obj => (obj as THREE.Mesh).geometry.dispose());
      vessel.clear();
      const start = cut ? 1.95 : 0, end = cut ? 6.05 : Math.PI * 2;
      const xyz = (x: number, r: number, a: number) => [x, r * Math.cos(a), r * Math.sin(a)];
      const add = (g: THREE.BufferGeometry, m: THREE.Material) => vessel.add(new THREE.Mesh(g, m));
      add(surface((u, v) => xyz((u - .5) * 7.2, 1.2, start + v * (end - start))), wall);
      add(surface((u, v) => xyz((u - .5) * 7.2, 1, start + v * (end - start))), lining);
      for (const x of [-3.6, 3.6]) add(surface((u, v) => xyz(x, 1 + u * .2, start + v * (end - start)), 2), cutWall);
      if (cut) for (const a of [start, end]) add(surface((u, v) => xyz((u - .5) * 7.2, 1 + v * .2, a), 24, 2), cutWall);
      if (n > 0) {
        add(surface((u, v) => {const x = (u - .5) * 5.2; return xyz(x, lumenRadius(x, n) - .002, start + v * (end - start));}), plaque);
        if (cut) for (const a of [start, end]) add(surface((u, v) => {const x = (u - .5) * 5.2, r = lumenRadius(x, n); return xyz(x, r + v * (1 - r), a);}, 64, 2), plaqueCut);
      }
      positionCells();
      draw();
    }
    let phase = 0;
    function positionCells() {
      cells.forEach((cell, i) => {
        const x = ((i / cells.length * 7.2 + phase) % 7.2) - 3.6;
        const angle = i * 2.399;
        const radius = Math.max(0, lumenRadius(x, currentNarrowing) - .19) * (.25 + (i % 5) * .13);
        cell.position.set(x, radius * Math.cos(angle), radius * Math.sin(angle));
      });
    }
    function resetView(next: Props['view']) {
      camera.position.set(...(next === 'end' ? [11.8, .01, .01] : [3.5, 3.7, 10.2]) as [number, number, number]);
      camera.zoom = 1; camera.updateProjectionMatrix(); controls.target.set(0, 0, 0); controls.update(); draw();
    }
    api.current = {update: rebuild, section: position => {sectionMarker.position.x = clampSectionPosition(position); draw();}, motion: moving, reset: resetView};
    resetView(view);
    rebuild(narrowing, cutaway);
    const resize = new ResizeObserver(() => {
      const width = container.clientWidth, height = container.clientHeight;
      if (!width || !height) return;
      renderer.setSize(width, height); camera.aspect = width / height; camera.updateProjectionMatrix(); draw();
    });
    resize.observe(container);
    let inView = true;
    const intersection = new IntersectionObserver(([entry]) => {inView = entry.isIntersecting;}); intersection.observe(container);
    let frame = 0, previous = performance.now(), lost = false;
    const animate = (now: number) => {
      frame = requestAnimationFrame(animate);
      const delta = Math.min((now - previous) / 1000, .05); previous = now;
      if (document.hidden || !inView || lost) return;
      if (api.current?.motion) {phase = (phase + delta * .55) % 7.2; positionCells();}
      controls.update(); draw();
    };
    frame = requestAnimationFrame(animate);
    const onLost = (event: Event) => {event.preventDefault(); lost = true; setFailed(true); setReady(false);};
    renderer.domElement.addEventListener('webglcontextlost', onLost);
    const onKey = (event: KeyboardEvent) => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', '+', '=', '-', 'Home'].includes(event.key)) return;
      event.preventDefault();
      if (event.key === 'Home') resetView('side');
      else if (['+', '=', '-'].includes(event.key)) {
        camera.zoom = THREE.MathUtils.clamp(camera.zoom + (event.key === '-' ? -.1 : .1), .6, 1.8); camera.updateProjectionMatrix();
      } else {
        const spherical = new THREE.Spherical().setFromVector3(camera.position);
        spherical.theta += event.key === 'ArrowLeft' ? -.14 : event.key === 'ArrowRight' ? .14 : 0;
        spherical.phi = THREE.MathUtils.clamp(spherical.phi + (event.key === 'ArrowUp' ? -.14 : event.key === 'ArrowDown' ? .14 : 0), .15, Math.PI - .15);
        camera.position.setFromSpherical(spherical); controls.update();
      }
      draw();
    };
    const onZoom = (event: Event) => {
      camera.zoom = THREE.MathUtils.clamp(camera.zoom + (event as CustomEvent<number>).detail, .6, 1.8);
      camera.updateProjectionMatrix(); draw();
    };
    container.addEventListener('keydown', onKey);
    container.addEventListener('artery-zoom', onZoom);
    setReady(true);
    return () => {
      cancelAnimationFrame(frame); resize.disconnect(); intersection.disconnect(); controls.dispose();
      container.removeEventListener('keydown', onKey); container.removeEventListener('artery-zoom', onZoom);
      renderer.domElement.removeEventListener('webglcontextlost', onLost);
      vessel.children.forEach(obj => (obj as THREE.Mesh).geometry.dispose());
      [wall, lining, cutWall, plaque, plaqueCut, cellMaterial].forEach(m => m.dispose()); cellGeometry.dispose();
      sectionRingGeometry.dispose(); sectionPlaneGeometry.dispose(); sectionRingMaterial.dispose(); sectionPlaneMaterial.dispose();
      renderer.dispose(); renderer.domElement.remove(); api.current = null;
    };
    // Scene ownership is tied to mount. State updates below do not recreate WebGL contexts.
  }, []);
  useEffect(() => {api.current?.update(narrowing, cutaway);}, [narrowing, cutaway]);
  useEffect(() => {api.current?.section(sectionPosition);}, [sectionPosition]);
  useEffect(() => {if (api.current) api.current.motion = moving;}, [moving]);
  useEffect(() => {api.current?.reset(view);}, [reset, view]);

  return <div className="artery-renderer">
    <div ref={host} className="artery-canvas" role="group" tabIndex={0}
      aria-label={t('Интерактивная 3D-модель артерии. Стрелки — вращение, плюс и минус — масштаб, Home — сброс.','Артерияның интерактивті 3D моделі. Бағыттау пернелері — айналдыру, плюс пен минус — масштаб, Home — қалпына келтіру.')}
      aria-describedby="artery-description" style={failed ? {display: 'none'} : undefined}/>
    {!ready && !failed && <div className="artery-loading" role="status">{t('Создаём 3D-модель…','3D модель жасалуда…')}</div>}
    {failed && <div className="artery-fallback" role="status"><strong>{t('3D недоступно в этом браузере','Бұл браузерде 3D қолжетімсіз')}</strong><p>{t('Ниже остаётся интерактивное поперечное сечение. Ползунок работает и без WebGL.','Төмендегі интерактивті көлденең қима WebGL болмаса да жұмыс істейді.')}</p></div>}
    {!failed && <div className="artery-zoom"><button type="button" onClick={() => host.current?.dispatchEvent(new CustomEvent('artery-zoom', {detail: .15}))} aria-label={t('Увеличить модель','Модельді үлкейту')}>+</button><button type="button" onClick={() => host.current?.dispatchEvent(new CustomEvent('artery-zoom', {detail: -.15}))} aria-label={t('Уменьшить модель','Модельді кішірейту')}>−</button></div>}
  </div>;
}
